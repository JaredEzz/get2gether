import 'package:get2gether/model/activity.dart';

class Category{
  String _name;
  List<Activity> _activities;
}