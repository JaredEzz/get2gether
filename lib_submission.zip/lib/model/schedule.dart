import 'package:get2gether/model/activity.dart';
import 'package:get2gether/model/user.dart';

class Schedule{
  int _ownerId;

  List<ScheduledActivity> _activities;
}