class Review {
  String _reviewerName;
  double _score;
  String _reviewBody;

  Review(){}


}