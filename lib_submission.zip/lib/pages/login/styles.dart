import 'package:flutter/material.dart';

DecorationImage backgroundImage = new DecorationImage(
  image: new ExactAssetImage(''),
  //TODO add login background image
  fit: BoxFit.cover,
);